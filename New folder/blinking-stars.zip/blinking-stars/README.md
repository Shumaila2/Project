# Blinking Stars

A Pen created on CodePen.io. Original URL: [https://codepen.io/edmundojr/pen/ONdEoP](https://codepen.io/edmundojr/pen/ONdEoP).

