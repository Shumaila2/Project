# CSS Slime Attack

A Pen created on CodePen.io. Original URL: [https://codepen.io/Hornebom/pen/mdaBjE](https://codepen.io/Hornebom/pen/mdaBjE).

