# JavaScript Confetti

A Pen created on CodePen.io. Original URL: [https://codepen.io/cerpow/pen/RwNaeOb](https://codepen.io/cerpow/pen/RwNaeOb).

Creating confetti on any webpage without using canvas.